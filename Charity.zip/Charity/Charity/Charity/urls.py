"""Charity URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from my_app.views import *


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name="home"),
    path('about/', about, name="about"),
    path('contact/', contact, name="contact"),
    path('donator_signup/', donator_signup, name="donator_signup"),
    path('login/', Login, name="login"),
    path('logout/', Logout, name="logout"),
    path('profile/', profile, name="profile"),
    path('edit_profile/', Edit_profile, name="edit_profile"),
    path('change_password/', change_password, name="change_password"),
    path('donation/<int:pid>', donation, name="donation"),
    path('detail/<int:pid>', detail, name="detail"),
    path('learn_more/<int:pid>', learn_more, name="learn_more"),
    path('my_donation/', my_donation, name="my_donation"),
    path('all_needy_people/', all_needy_people, name="all_needy_people"),

#Admin
    path('admin_login/', AdminLogin, name="admin_login"),
    path('admin_home/', admin_home, name="admin_home"),
    path('add_people/', add_people, name="add_people"),
    path('view_people/', view_people, name="view_people"),
    path('view_donator/', view_donator, name="view_donator"),
    path('view_donation/', view_donation, name="view_donation"),
    path('delete_donation/<int:pid>', delete_donation, name="delete_donation"),
    path('delete_donator/<int:pid>', delete_donator, name="delete_donator"),
    path('delete_needy/<int:pid>', delete_needy, name="delete_needy"),
    path('edit_people/<int:pid>', edit_people, name="edit_people"),
    path('change_status/<int:pid>', change_status, name="change_status"),
    path('payment/<int:pid>', payment, name="payment"),

]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
