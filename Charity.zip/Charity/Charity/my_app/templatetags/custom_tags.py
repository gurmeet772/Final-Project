from django import template
register = template.Library()

@register.simple_tag
def getpercent(goal, current):
    return (int(current)*100)/int(goal)