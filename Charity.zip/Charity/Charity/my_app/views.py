from math import remainder
from django.shortcuts import render, redirect
from matplotlib.collections import Collection
from .models import *
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

# Create your views here.
def home(request):
    if request.user.is_staff:
        return redirect('admin_home')
    people = HelpingPeople.objects.all()
    return render(request, 'user_templates/home.html', {'data':people})

def all_needy_people(request):
    if not request.user.is_authenticated:
        return redirect('login')
    people = HelpingPeople.objects.all()
    return render(request, 'user_templates/all_needy_people.html', {'data':people})

def about(request):
    return render(request, 'user_templates/about.html')

def contact(request):
    return render(request, 'user_templates/contact.html')

def donator_signup(request):
    if request.method == 'POST':
        f = request.POST['fname']
        l = request.POST['lname']
        u = request.POST['uname']
        p = request.POST['pwd']
        d = request.POST['date']
        ad = request.POST['add']
        e = request.POST['email']
        i = request.FILES['img']
        gen = request.POST['gender']
        con = request.POST['mobile']
        user = User.objects.create_user(username=u, email=e, password=p, first_name=f,last_name=l)
        Donator.objects.create(user=user, dob=d, address=ad, mobile=con, image=i, gender=gen)
        messages.success(request, "Registration Successfull")
        return redirect('login')
    return render(request, 'accounts/register.html')

def Login(request):
    if request.method == "POST":
        u = request.POST['uname']
        p = request.POST['pwd']
        user = authenticate(username=u, password=p)
        try:
            if user:
                login(request, user)
                messages.success(request, "Logged in Successfully")
                return redirect('home')
            else:
                messages.success(request, "Invalid User")
        except:
            messages.success(request, "Invalid User")
    return render(request,'accounts/login.html')


def Logout(request):
    logout(request)
    return redirect('home')

def change_password(request):
    if not request.user.is_authenticated:
        return redirect('login')
    if request.method=="POST":
        n = request.POST['pwd1']
        c = request.POST['pwd2']
        o = request.POST['pwd3']
        if c == n:
            u = User.objects.get(username__exact=request.user.username)
            u.set_password(n)
            u.save()
            messages.success(request, "Password changed successfully")
        else:
            messages.success(request, "Password not matching")
    if not request.user.is_staff:
        return render(request,'user_templates/change_password.html')
    else:
        return render(request,'home/change_password.html')


def profile(request):
    if not request.user.is_authenticated:
        return redirect('login')
    user = User.objects.get(id=request.user.id)
    pro = Donator.objects.get(user=user)
    d={'pro':pro,'user':user}
    return render(request,'user_templates/profile.html',d)

def detail(request, pid):
    if not request.user.is_authenticated:
        return redirect('login')
    data = CollectedAmount.objects.get(id=pid)
    mydata = None
    d={'data':data, 'my_data':mydata}
    return render(request,'user_templates/detail.html',d)

def learn_more(request, pid):
    help = HelpingPeople.objects.get(id=pid)
    mydata = CollectedAmount.objects.filter(people=help)
    d={'data':help, 'my_data':mydata}
    return render(request,'user_templates/learn_more.html',d)

def Edit_profile(request):
    if not request.user.is_authenticated:
        return redirect('login')
    user=User.objects.get(id=request.user.id)
    pro = Donator.objects.get(user=user)
    
    if request.method == 'POST':
        f = request.POST['fname']
        l = request.POST['lname']
        g = request.POST['gender']
        ad = request.POST['add']
        e = request.POST['email']
        con = request.POST['mobile']
        d = request.POST['date']

        try:
            i = request.FILES['img']
            pro.image = i
            pro.save()

        except:
            pass


        if d:
            try:
                pro.dob = d
                pro.save()
            except:
                pass
        else:
            pass

        pro.user.first_name=f
        pro.user.last_name=l
        pro.user.email=e
        pro.mobile=con
        pro.gender=g
        pro.address=ad
        pro.save()
        messages.success(request, "Profile Updated Successfully")
        return redirect('profile')
    d = {'pro':pro}
    return render(request, 'user_templates/edit_profile.html',d)

def donation(request, pid):
    if not request.user.is_authenticated:
        return redirect('login')
    data = HelpingPeople.objects.get(id=pid)
    remainder = int(data.goal) - int(data.current)
    if request.method == "POST":
        u = request.POST['amount']
        data.current = int(data.current) + int(u)
        data.save()
        user = Donator.objects.get(user=request.user)
        colobj = CollectedAmount.objects.create(amount=u, donator=user, people=data)
        return redirect('payment', colobj.id)
    return render(request, 'user_templates/donate.html', {'data':data, 'remainder':remainder})

def my_donation(request):
    if not request.user.is_authenticated:
        return redirect('login')
    user = Donator.objects.get(user=request.user)
    data = CollectedAmount.objects.filter(donator=user)
    return render(request, 'user_templates/my_donation.html', {'data':data})

def admin_home(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    people = HelpingPeople.objects.all()
    donators = Donator.objects.all()
    donation_data = CollectedAmount.objects.all()
    donation = 0
    for i in donation_data:
        donation+=int(i.amount)
    d = {'people':people.count(), 'donators':donators.count(), 'donation':donation_data.count(), 'amount':donation}
    return render(request, 'home/index.html',d)

def AdminLogin(request):
    if request.method == "POST":
        u = request.POST['uname']
        p = request.POST['pwd']
        user = authenticate(username=u, password=p)
        try:
            if user.is_staff:
                login(request, user)
                messages.success(request, "Logged in Successfully")
                return redirect('admin_home')
            else:
                messages.success(request, "Invalid User")
        except:
            messages.success(request, "Invalid User")
    return render(request,'home/login.html')

def add_people(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    if request.method == 'POST':
        f = request.POST['name']
        i = request.FILES['image']
        a = request.POST['adhar']
        ad = request.POST['address']
        desc = request.POST['desc']
        amt = request.POST['amount']
        d = request.POST['last_date']
        HelpingPeople.objects.create(name=f, image=i, address=ad, description=desc, goal=amt, last_date=d, aadhar_card=a)
        messages.success(request, "New data created")
        return redirect('view_people')
    return render(request, 'home/add_people.html')

def view_people(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    data = HelpingPeople.objects.all()
    return render(request, 'home/view_people.html', {'data':data})

def view_donator(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    data = Donator.objects.all()
    return render(request, 'home/view_donator.html', {'data':data})

def view_donation(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    data = CollectedAmount.objects.all()
    return render(request, 'home/view_donation.html', {'data':data})

def delete_donation(request, pid):
    data = CollectedAmount.objects.get(id=pid)
    data.delete()
    messages.success(request, "Data deleted")
    if request.user.is_staff:
        return redirect('view_donation')
    else:
        return redirect('my_donation')

def delete_donator(request, pid):
    data = Donator.objects.get(id=pid)
    data.delete()
    messages.success(request, "Data deleted")
    return redirect('view_donator')

def delete_needy(request, pid):
    data = HelpingPeople.objects.get(id=pid)
    data.delete()
    messages.success(request, "Data deleted")
    return redirect('view_people')



def edit_people(request, pid):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    data = HelpingPeople.objects.get(id=pid)
    if request.method == 'POST':
        f = request.POST['name']
        try:
            i = request.FILES['image']
            data.image = i
            data.save()
        except:
            pass
        a = request.POST['adhar']
        ad = request.POST['address']
        desc = request.POST['desc']
        amt = request.POST['amount']
        d = request.POST['last_date']
        HelpingPeople.objects.filter(id=pid).update(name=f, address=ad, description=desc, goal=amt, last_date=d, aadhar_card=a)
        messages.success(request, "Data updated")
        return redirect('view_people')
    return render(request, 'home/edit_people.html', {'data':data})

def change_status(request, pid):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    data = CollectedAmount.objects.get(id=pid)
    data.status = "Approved"
    data.save()
    messages.success(request, "Status Approved")
    return redirect('view_donation')

def payment(request, pid):
    collected = CollectedAmount.objects.get(id=pid)
    if request.method == "POST":
        messages.success(request, "Donated Successfully")
        return redirect('my_donation')
    return render(request, 'user_templates/payment.html', {'total':collected.amount})

