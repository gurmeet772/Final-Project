from operator import mod
from re import T
from django.db import models
from regex import B
from django.contrib.auth.models import User
from torch import mode

# Create your models here.
class HelpingPeople(models.Model):
    name = models.CharField(max_length=100, null=True, blank=True)
    aadhar_card = models.CharField(max_length=100, null=True, blank=True)
    address = models.CharField(max_length=100, null=True, blank=True)
    title = models.CharField(max_length=100, null=True, blank=True)
    goal = models.CharField(max_length=100, null=True, blank=True)
    current = models.CharField(max_length=100, null=True, blank=True, default=0)
    last_date = models.DateField(null=True, blank=True)
    image = models.FileField(null=True, blank=True)
    description = models.FileField(null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return self.name

class Donator(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    mobile = models.CharField(max_length=100, null=True, blank=True)
    address = models.CharField(max_length=100, null=True, blank=True)
    dob = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=100, null=True, blank=True)
    image = models.FileField(null=True, blank=True)

    def __str__(self) -> str:
        return self.user.username

class CollectedAmount(models.Model):
    donator = models.ForeignKey(Donator, on_delete=models.CASCADE, null=True, blank=True)
    people = models.ForeignKey(HelpingPeople, on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=100, null=True, blank=True, default="Pending")
    amount = models.CharField(max_length=100, null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return self.donator.user.username +" " + self.people.name